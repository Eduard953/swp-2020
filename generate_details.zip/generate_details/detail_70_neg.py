from PIL import Image, ImageDraw
import json, os, sys
from main_dataprep import *

def extract_detail(image, x, y, index, image_filename):
    image_path, image_base = os.path.split(image_filename)
    image_base = os.path.splitext(image_base)[0] # strip extension
    detail_path = '../ground_truths/0/'
    if not os.path.exists(detail_path):
        os.mkdir(detail_path)
    detail_base = os.path.join(detail_path, image_base)
    print("Extracting details for {}".format(image_filename))
    print("\tto {}*".format(detail_base))
    detail_filename = detail_base + "_{}.png".format(index)
    left = x - 35
    top = y - 35
    right = x + 35
    bottom = y + 35
    detail = image.crop((left, top, right, bottom))
    detail.save(detail_filename)

def detail_70(given_arguments):
    for json_filename in given_arguments:
        j = json.load(open(json_filename))

        dirname_json, filename = os.path.split(json_filename)
        dirname_img = dirname_json.replace('new_ann', 'img/')
        image_filename = dirname_img + os.path.splitext(filename)[0] + '.png'
        
        points = j['negatives']

        original = Image.open(image_filename)

        if original.mode == 'L':
            original = original.convert('RGBA')

        index = 0
        for x, y in points:
            extract_detail(original, x, y, index, image_filename)
            index = index + 1