import random
import os, sys, json
from PIL import Image, ImageDraw
from main_dataprep import *

def find_rand_negative(original, points, width, height):    
    ret = 0

    while ret == 0:
        x = random.randint(35, width-35)
        y = random.randint(35, height-35)
        if not(check_distance(x, y, points)):
            ret = 0
        else:
            ret = 1

    return x, y


def check_distance(x, y, points):
    for tuples in points:
        if x < tuples[0]+70 and x > tuples[0]-70 and y < tuples[1]+70 and y > tuples[1]-70:
            print('distance between random negatives too little')
            return False
    return True


def check_for_negative_double(x, y, neg_pixels):
    i = 0

    while i < len(neg_pixels):
        if [x, y] == neg_pixels[i]:
            print('[x,y] already exists')
            return False
        i = i + 1
    return True


def save_negatives_array(image_filename, points):
    original = Image.open(image_filename)
    width, height = original.size
    neg_pixels = []

    for i in range(5):
        x, y = find_rand_negative(original, points, width, height)
        while not(check_for_negative_double(x, y, neg_pixels)):
            x, y = find_rand_negative(original, points, width, height)
        neg_pixels += [[x, y]]
    return neg_pixels


def rand_negatives(given_arguments):
   for json_filename in given_arguments:
        print('Processing: {}'.format(json_filename))
        j = json.load(open(json_filename))
        print(json_filename)

        dirname_json, filename = os.path.split(json_filename)
        dirname_img = dirname_json.replace('new_ann', 'img/')
        image_filename = dirname_img + os.path.splitext(filename)[0] + '.png'

        points = j['positives']

        print('\tStoring into: {}'.format(json_filename))
        neg_pixels = save_negatives_array(image_filename, points)

        original_filename = os.path.basename(image_filename).replace('_markiert.', '.')
        d = {
            'filename': original_filename,
            'positives': points,
            'negatives': neg_pixels
            }

        f = open(json_filename, 'w')
        json.dump(d, f, indent = 4)