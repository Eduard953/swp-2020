import json
import os, sys
from main_dataprep import *

def sort_pixels(given_arguments):
    for json_filename in given_arguments:
        dirname, filename = os.path.split(json_filename)
        image_filename = os.path.splitext(filename)[0]
        new_file = os.path.splitext(image_filename)[0] + '.json'
        print('Getting pixels from: ', json_filename)
        open_json = json.load(open(json_filename))
        pixels = []
        if len(open_json['objects'])==0:
            print('empty, todo: random crops')
        else:
            json_objects = open_json['objects']
            for obj in json_objects:
                pixels += obj['points']['exterior']
        d = {'filename' : image_filename,
             'positives' : pixels}
        f = open(dirname.replace('ann', 'new_ann/') + new_file, 'w')
        json.dump(d, f, indent=4)