#!/usr/bin/env python3

"""
# folder structure 


Software Projekt/
├── BeesBook/
│   ├── 0/
│   │     ├── ann/
│   │     │    └── jsonfiles...
│   │     ├── img/
│   │     │    └── images...
│   │     └── new_ann/
│   │     │    └── jsonfiles... (clean dict)
│   ├── 1/
│   │     ├── ann/
│   │     │    └── jsonfiles...
│   │     ├── img/
│   │     │    └── images...
│   │     └── new_ann/
│   │     │    └── jsonfiles... (clean dict)
│   │
│   └─   # 3, 4 etc. for each batch of annotated imgs from supervisly
│
├── ground_truths/
│
└── generate_details/
      └── main_dataprep.py + corresponding python-files

also example img:
frame_00000_1.png
frame_00000 -> frame_00000 from corresponding folder
_1 -> iteration from the same image

ATTENTION: manually put 0_ (,1,2,3,4,...) before frame for corresponding folder
"""

import sys
import sort_pixels, rand_negatives, detail_70_pos, detail_70_neg

def main(args):
    if len(args) < 2:
        print('usage: main_dataprep.py (sort_pixels|rand_negatives|detail70_pos|detail70_neg')
    
    elif args[1] == 'sort_pixels':
        if len(args) < 3:
            print('usage: ground_truth.py sort_pixels <json-file(s)>')
        else:
            given_arguments = args[2:]
            sort_pixels.sort_pixels(given_arguments)

    elif args[1] == 'rand_negatives':
        if len(args) < 3:
            print('usage: ground_truth.py rand_negatives <json-file(s)>')
        else:
            given_arguments = args[2:]
            rand_negatives.rand_negatives(given_arguments)

    elif args[1] == 'detail70_pos':
        if len(args) < 3:
            print('usage: ground_truth.py detail_70_pos <json-file(s)>')
        else:
            given_arguments = args[2:]
            detail_70_pos.detail_70(given_arguments)

    elif args[1] == 'detail70_neg':
        if len(args) < 3:
            print('usage: ground_truth.py detail_70_neg <json-file(s)>')
        else:
            given_arguments = args[2:]
            detail_70_neg.detail_70(given_arguments)

    else:
        print('unknown command: {}'.format(args[1]))

if __name__ == '__main__':
    main(sys.argv)